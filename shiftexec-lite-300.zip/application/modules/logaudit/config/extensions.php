<?php
$extensions['shifts/zoom/menubar']['history'] = 'logaudit/object_zoom_menubar';
$extensions['shifts/zoom']['history'] = 'logaudit/index';
?>