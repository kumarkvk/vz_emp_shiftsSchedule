<?php
$extensions['admin/users/zoom/menubar']['loginlog']	= 'loginlog/user_zoom_menubar';
$extensions['admin/users/zoom']['loginlog']			= 'loginlog/index';
?>