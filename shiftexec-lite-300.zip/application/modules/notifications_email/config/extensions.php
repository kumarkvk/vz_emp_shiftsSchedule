<?php
$extensions['shifts/add/confirm']['notifications_email'] = 'notifications_email/add_form_inputs';
$extensions['shifts/zoom/confirm']['notifications_email'] = 'notifications_email/add_form_inputs';

$extensions['shifts/insert']['notifications_email'] = 'notifications_email/api_insert';
$extensions['shifts/update']['notifications_email'] = 'notifications_email/api_insert';
?>