<?php
/* these are subjects for email notifications */
$config['notifications_email:shift.owner.published']	= HCM::__('Shift published');
$config['notifications_email:shift.owner.cancelled']	= HCM::__('Shift cancelled');
$config['notifications_email:shift.owner.changed']		= HCM::__('Shift changed');
$config['notifications_email:timeoff.owner.published']	= HCM::__('Timeoff published');
$config['notifications_email:timeoff.owner.pending']	= HCM::__('Timeoff request pending');
$config['notifications_email:timeoff.admin.pending']	= HCM::__('Timeoff request pending');
$config['notifications_email:timeoff.owner.cancelled']	= HCM::__('Timeoff cancelled');
