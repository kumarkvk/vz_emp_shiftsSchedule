<?php
$extensions['shifts/zoom/menubar']['conflicts']		= 'conflicts/shift_zoom_menubar';
$extensions['shifts/zoom']['conflicts']				= 'conflicts/index';
$extensions['shifts/quickview']['conflicts']		= 'conflicts/quickview';
$extensions['shifts/assign/quickview']['conflicts']	= 'conflicts/quickview';

$extensions['list/quickstats']['conflicts']			= 'conflicts/quickstats';
$extensions['list/filter']['conflicts']				= 'conflicts/list/filter';

$extensions['admin/todo']['conflicts']				= 'conflicts/todo';
