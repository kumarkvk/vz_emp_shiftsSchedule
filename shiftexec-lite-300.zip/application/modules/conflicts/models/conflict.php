<?php
class Conflict_HC_Model extends MY_Model_Virtual
{
	protected $type;
	public $details;
	public $shift_id;
	public $id;
}