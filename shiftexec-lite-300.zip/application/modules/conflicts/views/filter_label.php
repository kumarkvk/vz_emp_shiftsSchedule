<?php
$label = HCM::__('Conflicts');
echo $label;
?>