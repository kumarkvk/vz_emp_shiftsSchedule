<?php
$CI =& ci_get_instance();
$modules = $CI->hc_modules;

$extensions['admin/todo']['open']	= 'admin/todo/open';
$extensions['admin/todo']['pending_timeoffs']	= 'admin/todo/pending_timeoffs';