<?php
$config['menu_conf_settings:core']	= HCM::__('Settings');
$config['menu_conf_settings:timeoff']	= HCM::__('Timeoff Requests');
$config['menu_conf_settings:wall']		= HCM::__('Full Schedule');
