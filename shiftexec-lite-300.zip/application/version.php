<?php
$config['hc_app_version'] = '3.0.0';
$config['nts_dbprefix_version'] = 'v3';
