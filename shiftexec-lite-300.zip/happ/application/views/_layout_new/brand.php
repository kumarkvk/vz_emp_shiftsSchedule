<p>
<a href="<?php echo $brand_url; ?>">
	<?php echo $brand_title; ?> <small><?php echo $app_version; ?></small>
</a>
</p>