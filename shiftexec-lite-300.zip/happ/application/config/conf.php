<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* some settings that cannot be edited in admin area */
$config = array();
$config['user.password_changed']	= HCM::__('Password changed');
