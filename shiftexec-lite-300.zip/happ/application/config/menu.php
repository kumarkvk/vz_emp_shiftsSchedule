<?php defined('BASEPATH') OR exit('No direct script access allowed');
/* menu example */
$config = array();

/*
$config[USER_HC_MODEL::LEVEL_ADMIN]['100m'] = array( 
	'Customers',
	'customers/admin',
	10
	);
$config[USER_HC_MODEL::LEVEL_ADMIN]['200m'] = array( 
	'Settings',
	array(
		array( 'Settings Submenu 1',	'conf/admin' ),
		array( 'Settings Submenu 2',	'conf/admin2' ),
		array( 'Settings Submenu 3',	'conf/admin3' ),
		),
	100
	);
*/
/* End of file menu.php */
/* Location: ./application/config/menu.php */