<?php
$out = HC_Html_Factory::element('h2')
	->add_child('Login Log')
	;
echo $out->render();
?>